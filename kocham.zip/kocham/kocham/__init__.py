import characters
import corpus
import imap
import solve
import translate
import unique
