#!/usr/bin/env python
__doc__ = '''
functions for generating and/or processing a corpus (list of words)
'''

__all__ = ['english','bible','economy','polish','frequency','ifilter',
           'iselect','flatten','unflatten','ipassword','isample',
           'stopwords','more_stopwords','repeats']


import nltk
import itertools
from characters import replace, icombinations
import many_stop_words

VERBOSE = False

# wordlists generators
english = nltk.corpus.words.words
bible = nltk.corpus.gutenberg.words
economy = nltk.corpus.brown.words
polish = nltk.corpus.pl196x.words  # 1960's Polish
#XXX: get nkjp corpus

# stopwords
stopwords = nltk.corpus.stopwords.words
more_stopwords = many_stop_words.get_stop_words
#FIXME: get list of polish stopwords

def strip(wordlist, remove=None):
    'remove the selected words from the wordlist'
    if remove is None: remove = ()
    _type = type(wordlist)
    return _type(word for word in wordlist if word not in set(remove))

def frequency(wordlist, most_common=None):
    'generate a frequency distribution from a wordlist'
    return nltk.FreqDist(wordlist).most_common(most_common)
    #XXX: remove/convert all to only string.lower?

def repeats(wordlist):
    return dict(frequency(dict(frequency(wordlist)).values()))

def ceildiv(numerator,denominator):
  'division for integers; if remainder, then round up'
  if type(denominator) in (int,long) and type(numerator) in (int,long):
      return numerator/denominator + bool(numerator%denominator)
  error = 'numerator and denominator must be integers'
  raise TypeError(error)

def accumulate(iterable):
  total = 0
  for x in iterable:
    total += x
    yield total

def flatten(wordlist):
    'flatten a wordlist into a single joined string and indices of each word'
    wordlist = tuple((word,len(word)) for word in wordlist)
    if not wordlist: return '',()
    wlen = tuple(accumulate(tuple(itertools.izip(*wordlist))[-1]))
    words = ''.join(tuple(itertools.izip(*wordlist))[0])
    return words,wlen


def unflatten(wordstring,wordlen):
    '''split a string of words into a tuple of words, where:
    - wordlen is a tuple of indices for each word
'''
    cast = type(wordlen)
    zero = cast((0,))
    null = cast((None,))
    words = (wordstring[s:f] for s,f in itertools.izip(zero+wordlen[:-1],wordlen[:-1]+null))
    return tuple(words)


def ipassword(wordlist, characters, minpass, maxpass, **options):
    '''generate a password iterator for all permutations of wordlist, where:
    - all possible combinations of characters are mixed in
    - minpass is minimum password length [default: 0 characters]
    - maxpass is maximum password length [default: 1000 characters]
    - the length of the shortest word is minword [default: 0 characters]
    - the length of the longest word is maxword [default: equal to maxpass]
    - if digits=False, digits are stripped [default: False]
    - if names=False, (uppercase) names are stripped [default: False]
    - if symbols=False, punctuation is stripped [default: False]
    - if reverse=True, words are reversed [default: False]
    - an ascii translator may be applied [default: translate.translate]
    - fixed is a wordlist that will not be filtered [default: None (nothing)]
    - remove is a wordlist of stopwords to be removed [default: None]
    - size is maximum subset size of available words [default: None (everything)]
    - if random=True, then pick subset members randomly [default: False]
    - most_common is the number of frequency-sorted words to use
    - sep is the string to use to join all words [default: '']
    - nsubs is the integer number of maximum substitutions to make [default: 0]
    - if flatten=False, yield results in nested lists [default: True]

NOTE: if most_common=None (the default), frequency-sort all words; however, if
most_common=False, don't frequency-sort all words. most_common is an int otherwise.

NOTE: up to nsubs characters will be substituted; leftovers will act as words
'''
    most_common = options.pop('most_common',None)
    minword = options.pop('minword',1)
    maxword = options.pop('maxword',None)
    flatten = options.pop('flatten',True)

    #XXX: min/max pass issues (see _ipassword)?
    words = ifilter(wordlist, minword, maxword, maxpass=maxpass, **options)

    # get all combinations of fixed words & passwords, must be at least minpass
    passwords = (_ipassword(word, characters, minpass, maxpass, **options) for word in words)
    # flatten into a single password iterator
    passwd = passwords or itertools.chain.from_iterable(passwords)
    return itertools.chain.from_iterable(passwd) if flatten else passwd


#XXX: good defaults for min/max pass?
def _ipassword(wordlist, characters, minpass=0, maxpass=100, **options):
    '''generate a password iterator for all permutations of wordlist, where:
    - all possible combinations of characters are mixed in
    - minpass is minimum password length
    - maxpass is maximum password length
    - fixed is a wordlist that will not be filtered [default: None (nothing)]
    - sep is the string to use to join all words [default: '']
    - nsubs is the integer number of maximum substitutions to make [default: 0]
NOTE: up to nsubs characters will be substituted; leftovers will act as words
'''
    sep = options.get('sep','')
    nsubs = options.get('nsubs',0)
    fixed = options.get('fixed', None)
    if sep is None: sep = ''
    if nsubs is None: nsubs = 0
    if fixed is None: fixed = ()
    izip = itertools.izip
    permutations = itertools.permutations
    from unique import ipermutations

    # get size of the wordstring, fixed, and seps
    #NOTE: wordlist has unique combinations (e.g. if 'foobar' then not 'barfoo')
    #XXX: if wordlist is not a small sample, this will take time...
    wordstring,wordlen = flatten(wordlist) #XXX: *includes* fixed
    sizewords = len(wordstring)
    fixedlen = 0 #len(''.join(fixed)) #XXX: clip fixed
    seplen = len(sep)*(len(wordlen)-1)#+ len(fixed)) #XXX: -1? -2? sep in chars?
    usedchar = max(0,fixedlen + sizewords + seplen)
    # adjust minpass/maxpass for fixed, sizewords, and sep
    maxchar = max(0,maxpass - usedchar + nsubs) #XXX: adjust nsubs here?
    minchar = max(0,minpass - usedchar + nsubs) #XXX: adjust nsubs here?
    if VERBOSE: print "%s: {base:%s, char:(%s,%s), subs: %s, sep: %s}" % (wordstring, usedchar, minchar, maxchar, nsubs, seplen) #XXX: VERBOSE

    # get remaning random character combinations (e.g. '12','21','11','22')
    chars = icombinations(characters, maxchar, minchar, cycle=False)
    if not usedchar:
        return iter(chars) #FIXME: should use sep?

    # all combinations of subs in one tuple, plus all combinations of leftovers
    #XXX: flatten or keep nested?
    queue = set()
    pwd = itertools.chain.from_iterable((
        ipermutations(
            unflatten(replace(wordstring,dict(izip(qq,c[:nsubs]))),wordlen)
            +tuple(c[nsubs:]))
        for qq in permutations(range(0,sizewords), len(c[:nsubs]))) 
        for c in chars)  ### if not minpass < sizewords+len(c[nsubs:]))
    # join words together to make password string
    #XXX: keep flattened or revert to nested?
    password = itertools.chain.from_iterable((sep.join(p) for p in w) for w in pwd)
    return password


def ifilter(wordlist, minlen=1, maxlen=None, translator=None, **flags):
    '''return an iterator of the subset of words from the wordlist, where:
    - the length of the shortest word is minlen
    - the length of the longest word is maxlen
    - maxpass is maximum password length [default: 1000 characters]
    - if digits=False, digits are stripped [default: False]
    - if names=False, (uppercase) names are stripped [default: False]
    - if symbols=False, punctuation is stripped [default: False]
    - if reverse=True, words are reversed [default: False]
    - an ascii translator may be applied [default: translate.translate]
    - fixed is a wordlist that will not be filtered [default: None (nothing)]
    - remove is a wordlist of stopwords to be removed [default: None]
    - size is maximum subset size of available words [default: None (everything)]
    - if random=True, then pick subset members randomly [default: False]
    - most_common is the number of frequency-sorted words to use
    - sep is the string to use to join all words [default: '']

NOTE: if most_common=None (the default), frequency-sort all words; however, if
most_common=False, don't frequency-sort all words. most_common is an int otherwise.
'''
   #- skip is an integer number of words to skip [default: 0]
    names = flags.get('names', False)
    digit = flags.get('digits', False)
    punct = flags.get('symbols', False)
    invert = flags.get('reverse', False)
    random = flags.pop('random', False)
    maxpass = flags.pop('maxpass', None)
    fixed = flags.pop('fixed', None)
    size = flags.pop('size', None)
   #skip = flags.pop('skip', None)
    common = flags.pop('most_common', None)
    sep = flags.get('sep', None)
    remove = flags.pop('remove',None)

    if common is None or common:
        wordlist = frequency(wordlist, common)  #XXX: is slow
    if size is None:
        size = len(wordlist) #XXX: doesn't work for iterators
    if translator is None:
        from translate import translate as translator
    if fixed is None:
        fixed = ()
    if remove is None:
        remove = ()
    if sep is None:
        sep = ''
    if maxpass is None:
        maxpass = 1000 # assumes largest password is 1000 characters
    if maxlen is None:
        maxlen = maxpass # longest word is length of maximum password

    # check for early exit
    if not size: return iter(()) #XXX: or iter(((),)) ?

    # reduce size (of words chosen) by number of fixed words
    chop = size-len(fixed) # if negative, we will trim fixed 
    size = max(0, chop) # number of non-fixed words to use
    # if more fixed words than size, then reduce number of fixed words
    fixed = fixed if chop >= 0 else fixed[:chop] #XXX: chop or combinations?
    """
    remains = minpass - len(''.join(fixed)) # nonfixed length of wordstring
    #NOTE: calc of len(password)  doesn't account for nchars-nsubs; fix in icombo 
    if size: #FIXME: increase minlen to meet minpass, if needed
        minlen = max(minlen, ceildiv(remains,size))
    """
    from characters import uppercase, symbols, digits, reverse
    words = tuple( #XXX: or iterator?
      str(translator(reverse(word) if invert else word)).lower() if names else
      str(translator(reverse(word) if invert else word))
      for word,_ in wordlist
      if minlen <= len(word) <= maxlen
      and (names or (word[0] not in uppercase))
      and (punct or (word[0] not in symbols))
      and (digit or (word[0] not in digits))
      )
    # remove stopwords
    remove = set(translator(reverse(word) if invert else word).lower() for word in remove)
    if remove: words = strip(words, remove)
    # check for early exit
    lenfixed = len(sep.join(fixed))
    if not len(fixed)+len(words): return iter(()) #XXX: or iter(((),)) ?
    # get all combinations of length range(size,0,-1)
    return itertools.chain.from_iterable((tuple(fixed)+c for c in itertools.combinations_with_replacement(isample(words, None, random), _size) if len(sep.join(c))+lenfixed <= maxpass) for _size in xrange(size,-1,-1))


def isample(words, selector, random=False):
    '''downsample tuple of words to the selected subset, where:
    - selector is an integer *OR* slice
    - if random=True, then pick a subset randomly
    '''
    words = list(words) # triggers iterator
    if random:
        import random
        random.shuffle(words)
    if selector is not None:
        if type(selector) is int:
            selector = slice(selector)
        words = words[selector]
    return (word for word in words)
    

#XXX: better if iterate through nested chunks of all words???
#     xxx = (itertools.islice(words,0,select) for xxx in xxx)
def iselect(words, select, skip=None, random=False):
    '''downsample tuple of words to the selected subset, where:
    - select is a tuple of indices *OR* an integer
    - skip is an integer number of words to skip
    - if random=True, then pick indices randomly

NOTE: a select tuple uses accumulative skip, with skip as multipliers
'''
    if select is None:
        return (word for word in words)
    if skip is None:
        skip = 0
    step = max(skip, 0) + 1
    if random: #XXX: may have seed issues in multiprocessing
        if type(select) is not int:
            select = len(select)
        import random
        words = list(words) #NOTE: triggers iterator
        size = len(words)
       #select,chop = range(0,size),select
       #random.shuffle(select) #XXX: this is shuffle, not step, on indices
       #select = select[:chop]
        select = [random.randint(0,size)] + \
                 [random.randint(0,step) for _ in xrange(select-1)]
    elif type(select) is int:
       #select = xrange(0,select*step,step)
        select = itertools.chain(
          (0,),
          itertools.repeat(skip,select-1)
          ) if select else iter(())
    else:
        select = ((step-1)*i for i in select)
    _words = itertools.cycle(words) #XXX: words should not appear twice...
    return (itertools.islice(_words, i, i+1).next() for i in select)
    #XXX: however needs to guarantee return of selected size (of words)


if __name__ in '__main__':
    assert ceildiv(5, 124567890987654321234567890) == 1L
    assert ceildiv(5, 10) == 1
    assert ceildiv(5, 5) == 1
    assert ceildiv(5, 4) == 2
    assert ceildiv(5, 2) == 3
    assert ceildiv(5, 1) == 5

    assert tuple(accumulate([1,2,3,4,5,6])) == (1, 3, 6, 10, 15, 21)
    assert tuple(accumulate([1])) == (1,)
    assert tuple(accumulate([])) == ()
    assert tuple(accumulate(iter([1,2]))) == (1, 3)

    assert flatten([]) == ('', ())
    assert flatten(['cat','dog','a']) == ('catdoga', (3, 6, 7))
    assert flatten(iter(['cat','dog','a'])) == ('catdoga', (3, 6, 7))
    assert unflatten('catdoga', (3, 6, 7)) == ('cat', 'dog', 'a')
    assert unflatten('catdoga', [3, 6, 7]) == ('cat', 'dog', 'a')
    assert unflatten('', ()) == ('',)

    words = ['cat','dog','apple','house']
    assert tuple(isample(words, 0)) == ()
    assert tuple(isample([], 0)) == ()
    assert tuple(isample([], 1)) == ()
    assert tuple(isample(words, 1)) == ('cat',)
    assert tuple(isample(words, 2)) == ('cat', 'dog')
    assert len(tuple(isample(words, 2, random=True))) == 2

    words = '12345'
    assert tuple(iselect([], 3, skip=3, random=False)) == ()
    assert tuple(iselect(words, 0, skip=3, random=False)) == ()
    assert tuple(iselect(words, 1, skip=3, random=False)) == ('1',)
    assert tuple(iselect(words, 3, skip=0, random=False)) == ('1', '2', '3')
    assert tuple(iselect(words, 3, skip=1, random=False)) == ('1', '3', '5')
    assert tuple(iselect(words, 3, skip=2, random=False)) == ('1', '4', '2')
    assert tuple(iselect(words, 3, skip=3, random=False)) == ('1', '5', '4')
    assert tuple(iselect([], [0,1], skip=3, random=False)) == ()
    assert tuple(iselect([], [], skip=3, random=False)) == ()
    assert tuple(iselect(words, [], skip=3, random=False)) == ()
    assert tuple(iselect(words, [0,1], skip=3, random=False)) == ('1', '5')
    assert tuple(iselect(words, [0,1], skip=1, random=False)) == ('1', '3')
    assert len(tuple(iselect(words, 3, skip=0, random=True))) == 3
    assert len(tuple(iselect(words, 3, skip=3, random=True))) == 3

    words = ['cat','dog','apple','house']
    assert tuple(ifilter(words, size=3, fixed=['foo'])) == (('foo', 'house', 'house'), ('foo', 'house', 'apple'), ('foo', 'house', 'dog'), ('foo', 'house', 'cat'), ('foo', 'apple', 'apple'), ('foo', 'apple', 'dog'), ('foo', 'apple', 'cat'), ('foo', 'dog', 'dog'), ('foo', 'dog', 'cat'), ('foo', 'cat', 'cat'), ('foo', 'house'), ('foo', 'apple'), ('foo', 'dog'), ('foo', 'cat'), ('foo',))
    assert tuple(ifilter(words, size=3, fixed=['foo','bar','zap'])) == (('foo', 'bar', 'zap'),)
    assert tuple(ifilter(words, size=1, fixed=['foo','bar','zap'])) == (('foo',),)
    assert tuple(ifilter(words, size=1, fixed=[])) == (('house',), ('apple',), ('dog',), ('cat',), ())
    assert tuple(ifilter(words, size=3, fixed=[])) == (('house', 'house', 'house'), ('house', 'house', 'apple'), ('house', 'house', 'dog'), ('house', 'house', 'cat'), ('house', 'apple', 'apple'), ('house', 'apple', 'dog'), ('house', 'apple', 'cat'), ('house', 'dog', 'dog'), ('house', 'dog', 'cat'), ('house', 'cat', 'cat'), ('apple', 'apple', 'apple'), ('apple', 'apple', 'dog'), ('apple', 'apple', 'cat'), ('apple', 'dog', 'dog'), ('apple', 'dog', 'cat'), ('apple', 'cat', 'cat'), ('dog', 'dog', 'dog'), ('dog', 'dog', 'cat'), ('dog', 'cat', 'cat'), ('cat', 'cat', 'cat'), ('house', 'house'), ('house', 'apple'), ('house', 'dog'), ('house', 'cat'), ('apple', 'apple'), ('apple', 'dog'), ('apple', 'cat'), ('dog', 'dog'), ('dog', 'cat'), ('cat', 'cat'), ('house',), ('apple',), ('dog',), ('cat',), ())
    assert tuple(ifilter(words, size=0, fixed=[])) == ()
    assert tuple(ifilter([], size=0, fixed=[])) == ()
    assert tuple(ifilter([], size=3, fixed=[])) == ()
    assert tuple(ifilter(words, size=3, maxpass=7)) == (('dog', 'dog'), ('dog', 'cat'), ('cat', 'cat'), ('house',), ('apple',), ('dog',), ('cat',), ())
    assert tuple(ifilter(words, size=3, maxpass=10)) == (('dog', 'dog', 'dog'), ('dog', 'dog', 'cat'), ('dog', 'cat', 'cat'), ('cat', 'cat', 'cat'), ('house', 'house'), ('house', 'apple'), ('house', 'dog'), ('house', 'cat'), ('apple', 'apple'), ('apple', 'dog'), ('apple', 'cat'), ('dog', 'dog'), ('dog', 'cat'), ('cat', 'cat'), ('house',), ('apple',), ('dog',), ('cat',), ())
    assert tuple(ifilter(words, size=3, maxpass=12)) == (('house', 'dog', 'dog'), ('house', 'dog', 'cat'), ('house', 'cat', 'cat'), ('apple', 'dog', 'dog'), ('apple', 'dog', 'cat'), ('apple', 'cat', 'cat'), ('dog', 'dog', 'dog'), ('dog', 'dog', 'cat'), ('dog', 'cat', 'cat'), ('cat', 'cat', 'cat'), ('house', 'house'), ('house', 'apple'), ('house', 'dog'), ('house', 'cat'), ('apple', 'apple'), ('apple', 'dog'), ('apple', 'cat'), ('dog', 'dog'), ('dog', 'cat'), ('cat', 'cat'), ('house',), ('apple',), ('dog',), ('cat',), ())
    assert tuple(ifilter(words, size=3, maxlen=3, maxpass=12)) == (('dog', 'dog', 'dog'), ('dog', 'dog', 'cat'), ('dog', 'cat', 'cat'), ('cat', 'cat', 'cat'), ('dog', 'dog'), ('dog', 'cat'), ('cat', 'cat'), ('dog',), ('cat',), ())
    assert tuple(ifilter([])) == ()
    assert tuple(ifilter([], size=3)) == ()
    assert tuple(ifilter([], size=3, most_common=5)) == ()
    assert tuple(ifilter([], size=3, most_common=5, random=True)) == ()
    assert tuple(ifilter([], size=3, most_common=5, random=True, minlen=0)) == ()
    assert tuple(ifilter([], size=3, most_common=5, random=True, maxlen=0)) == ()
    assert tuple(ifilter([], size=3, most_common=5, random=True, minpass=3)) == ()




# EOF
