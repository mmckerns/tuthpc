#!/usr/bin/env python
__doc__ = '''
functions for generating and/or processing strings of characters
'''

__all__ = ['digits','lowercase','uppercase','letters','symbols','nolowercase',
           'characters','reverse','replace','insert','icombinations',
           'windowssymbols','linuxsymbols','windows','linux']

import string
# collections of character strings
digits = string.digits
lowercase = string.lowercase
uppercase = string.uppercase
letters = string.letters
symbols = string.punctuation
windowssymbols = ''.join(c for c in symbols if c not in '<>:"/\|?*^')
linuxsymbols = ''.join(c for c in symbols if c not in ':/')
windows = digits+uppercase+windowssymbols
linux = digits+letters+linuxsymbols
nolowercase = digits+uppercase+symbols
characters = digits+letters+symbols

def reverse(word):
    '''reverse a string or tuple of strings'''
    _type = type(word)
    return _type(''.join(reversed(word)))

def replace(word, mapping):
    "replace values (sorted by key) in mapping (dict of {index:string})"
    _type = type(word)
    for index,sub in mapping.iteritems():
        if not 0 <= index < len(word):
            error = "index '%s' out of range(0,%s)" % (index,len(word))
            raise IndexError(error)
        word = word[:index]+str(sub)+word[index+1:]
    return _type(word)

def insert(word, mapping):
    "insert values (sorted by key) in mapping (dict of {index:string})"
    _type = type(word)
    for index,sub in sorted(mapping.iteritems()):
        if index < 0:
            error = '%s < 0, all indices must be 0 or greater' % index
            raise IndexError(error)
        word = word[:index]+str(sub)+word[index:]
    return _type(word)

#XXX: is sorted
def icombinations(characters, maxlen, minlen=1, cycle=True):#, **info):
   #NOTE: maxlen must be set, and should be set as below
   #maxlen = maxchar - len(''.join(fixed)) - len(flatten(words)[0])
    import itertools
    combinations = (lambda x,n: itertools.product(x,repeat=n)) if cycle else (lambda x,n: itertools.combinations_with_replacement(x,n))
    chars = itertools.chain.from_iterable((''.join(i) for i in combinations(set(characters),n)) for n in xrange(minlen,maxlen+1))
    return chars


if __name__ == '__main__':
    assert reverse(digits) == ''.join(reversed(digits))
    assert reverse(tuple(digits)) == tuple(i for i in reversed(tuple(digits)))
    assert reverse('') == ''
    assert reverse(()) == ()

    try:
        insert('1234321', {1:'q', -2:'w'})
        raise AssertionError('IndexError not raised')
    except IndexError:
        pass
    except Exception as e:
        raise AssertionError('raised %s' % e)
    assert insert('1234321', {}) == '1234321'
    assert insert('1234321', {1:'q', 2:'w'}) == '1qw234321'
    assert insert('1234321', {2:'q', 1:'w'}) == '1wq234321'
    assert insert('1234321', {100:'q'} )== '1234321q'
    assert insert('', {100:'q'}) == 'q'

    try:
        replace('1234321', {1:'q', -2:'w'})
        raise AssertionError('IndexError not raised')
    except IndexError:
        pass
    except Exception as e:
        raise AssertionError('raised %s' % e)
    try:
        assert replace('1234321', {100:'q'} )== '1234321'
        raise AssertionError('IndexError not raised')
    except IndexError:
        pass
    except Exception as e:
        raise AssertionError('raised %s' % e)
    try:
        assert replace('', {100:'q'}) == ''
        raise AssertionError('IndexError not raised')
    except IndexError:
        pass
    except Exception as e:
        raise AssertionError('raised %s' % e)
    assert replace('1234321', {}) == '1234321'
    assert replace('1234321', {1:'q', 2:'w'}) == '1qw4321'
    assert replace('1234321', {2:'q', 1:'w'}) == '1wq4321'


# EOF
