#!/usr/bin/env python
__doc__ = '''
archive for caching/archiving function calls
'''

__all__ = ['archived','active']

_active = False
_dummy = lambda x:x
_archive = _dummy


def active(active=None):
    global _active, _archive
    try:
        from klepto.archives import dir_archive
        from klepto import inf_cache as memoize
        from klepto.keymaps import keymap
        import imap
        server,user = imap.getconnection()
        name = '_'.join([user or 'test', server or 'database'])
        db = dir_archive(name, cached=False, serialized=False)
        keys = keymap(flat=True)
        archive = memoize(keymap=keys, cache=db)
    except ImportError:
        archive = _archive
    _active = _active if active is None else active
    _archive = archive if _active else _dummy
    return _active


def archived(x):
    return _archive(x)


# EOF
