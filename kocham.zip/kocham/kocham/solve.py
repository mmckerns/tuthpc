#!/usr/bin/env python

# __all__ = ['']
from corpus import ipassword

def _compare(pwd):
    from imap import login
    return login(pwd)

def _compared(pwds):
    import itertools
    res = itertools.imap(_compare, pwds)
    for x in res:
        if x:
            return x
    return

def _ucompared(pwds, n=100):
    from multiprocessing.dummy import Pool
    tp = Pool(n)
    res = tp.imap_unordered(_compare, pwds)
    for x in res:
        if x:
            return x
    return


def uiui(n=100, *args, **kwds):
    "solve using two (nested) unordered iterative parallel maps\n\n"
    from corpus import ipassword
    pwds = ipassword(flatten=False, *args, **kwds)
    from multiprocessing.dummy import Pool
    tp = Pool(n)
    res = tp.imap_unordered(_ucompared, pwds)
    for x in res:
        if x:
            print x
            break
uiui.__doc__ += ipassword.__doc__.replace('    - if flatten=False, yield results in nested lists [default: True]\n','    - n is the number of parallel workers')

def uii(n=100, *args, **kwds):
    "solve using an unordered iterative parallel map and an inner iterative map\n\n"
    from corpus import ipassword
    pwds = ipassword(flatten=False, *args, **kwds)
    from multiprocessing.dummy import Pool
    tp = Pool(n)
    res = tp.imap_unordered(_compared, pwds)
    for x in res:
        if x:
            print x
            break
uii.__doc__ += ipassword.__doc__.replace('    - if flatten=False, yield results in nested lists [default: True]\n','    - n is the number of parallel workers')

def ii(*args, **kwds):
    "solve using two (nested) iterative maps\n\n"
    from corpus import ipassword
    pwds = ipassword(flatten=False, *args, **kwds)
    import itertools
    res = itertools.imap(_compared, pwds)
    for x in res:
        if x:
            print x
            break
ii.__doc__ += ipassword.__doc__.replace('    - if flatten=False, yield results in nested lists [default: True]\n','')

def mi(*args, **kwds):
    "solve using a blocking map and an internal iterative map\n\n"
    from corpus import ipassword
    pwds = ipassword(flatten=False, *args, **kwds)
    x = set(map(_compared, pwds)).difference([None])
    if x:
        print tuple(x)[0]
mi.__doc__ += ipassword.__doc__.replace('    - if flatten=False, yield results in nested lists [default: True]\n','')

def fui(n=100, *args, **kwds):
    "solve using a for loop and an internal unordered iterative parallel map\n\n"
    from corpus import ipassword
    pwds = ipassword(flatten=False, *args, **kwds)
    from multiprocessing.dummy import Pool
    tp = Pool(n)
    for p in pwds:
        res = tp.imap_unordered(_compare, p)
        for x in res:
            if x:
                print x
                break
        if x:
            break
fui.__doc__ += ipassword.__doc__.replace('    - if flatten=False, yield results in nested lists [default: True]\n','    - n is the number of parallel workers')

def fi(*args, **kwds):
    "solve using a for loop and an internal iterative map\n\n"
    from corpus import ipassword
    pwds = ipassword(flatten=False, *args, **kwds)
    import itertools
    for p in pwds:
        res = itertools.imap(_compare, p)
        for x in res:
            if x:
                print x
                break
        if x:
            break
fi.__doc__ += ipassword.__doc__.replace('    - if flatten=False, yield results in nested lists [default: True]\n','')

def fm(*args, **kwds):
    "solve using a for loop and an internal blocking map\n\n"
    from corpus import ipassword
    pwds = ipassword(flatten=False, *args, **kwds)
    for p in pwds:
        x = set(map(_compare, p)).difference([None])
        if x:
            print tuple(x)[0]
            break
fm.__doc__ += ipassword.__doc__.replace('    - if flatten=False, yield results in nested lists [default: True]\n','')


def ff(*args, **kwds):
    "solve using two (nested) for loops\n\n"
    from corpus import ipassword
    pwds = ipassword(flatten=False, *args, **kwds)
    for p in pwds:
        for i in p:
            x = _compare(i)
            if x:
                print x
                break
        if x:
            break
ff.__doc__ += ipassword.__doc__.replace('    - if flatten=False, yield results in nested lists [default: True]\n','')


def flui(n=100, *args, **kwds):
    "solve flattened list using an unordered iterative parallel map\n\n"
    from corpus import ipassword
    pwds = ipassword(flatten=True, *args, **kwds)
    from multiprocessing.dummy import Pool
    tp = Pool(n) 
    res = tp.imap_unordered(_compare, pwds)
    for x in res:
        if x:
            print x
            break
flui.__doc__ += ipassword.__doc__.replace('    - if flatten=False, yield results in nested lists [default: True]\n','    - n is the number of parallel workers')
    
def fli(*args, **kwds):
    "solve flattened list using an iterative map\n\n"
    from corpus import ipassword
    pwds = ipassword(flatten=True, *args, **kwds)
    import itertools
    res = itertools.imap(_compare, pwds)
    for x in res:
        if x:
            print x
            break
fli.__doc__ += ipassword.__doc__.replace('    - if flatten=False, yield results in nested lists [default: True]\n','')

    
def flm(*args, **kwds):
    "solve flattened list using a blocking map\n\n"
    from corpus import ipassword
    pwds = ipassword(flatten=True, *args, **kwds)
    x = set(map(_compare, pwds)).difference([None])
    if x:
        print tuple(x)[0]
flm.__doc__ += ipassword.__doc__.replace('    - if flatten=False, yield results in nested lists [default: True]\n','')


def flf(*args, **kwds):
    "solve flattened list using a for loop\n\n"
    from corpus import ipassword
    pwds = ipassword(flatten=True, *args, **kwds)
    for p in pwds:
        x = _compare(p)
        if x:
            print x
            break
flf.__doc__ += ipassword.__doc__.replace('    - if flatten=False, yield results in nested lists [default: True]\n','')


# EOF
