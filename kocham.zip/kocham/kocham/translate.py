#!/usr/bin/env python
__doc__ = '''
translation functions for removing/replacing non-ascii characters
'''

__all__ = ['nfd','nfkd','translate']

import trans, unicodedata
translate = lambda word: str(trans.trans(unicode(word))) #XXX: cast to str?
nfd = lambda word: unicodedata.normalize('NFD', unicode(word)).encode('ascii', 'ignore')
nfkd = lambda word: unicodedata.normalize('NFKD', unicode(word)).encode('ascii', 'ignore')

if __name__ == '__main__':
    pass


# EOF
