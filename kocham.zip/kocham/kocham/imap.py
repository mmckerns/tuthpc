#server = 'poczta.o2.pl'
#user = 'username'
#
_passwd = ''
_delay = 0
_server = ''
_user = ''

VERBOSE = False

def setconnection(server=None,user=None):
    global _server, _user
    _server = _server if server is None else server
    _user = _user if user is None else user
    return

def setpass(password=None):
    global _passwd
    import getpass
    _passwd = getpass.getpass() if password is None else password
    return

def setdelay(delay=None):
    global _delay
    _delay = 0 if delay is None else delay
    return

def dummy(server=None, user=None):
    def compare(passwd=None):
        if passwd is None:
            import getpass
            passwd = getpass.getpass()
        import time
        time.sleep(_delay)
        return passwd if passwd == _passwd else None
    return compare

compare = dummy()

def connection(server, user):
    def login(passwd=None):
        if passwd is None:
            import getpass
            passwd = getpass.getpass()
        import imaplib
        M = imaplib.IMAP4_SSL(server)
        try:
            M.login(user, passwd)
            M.logout()
        except:
            passwd = None
        return passwd
    return login

def login(passwd=None):
    server, user = _server, _user
    if VERBOSE: print "%s %s %s\n" % (server, user, passwd) #XXX: VERBOSE
    if not server or not user:
        return compare(passwd)
    if passwd is None:
        import getpass
        passwd = getpass.getpass()
    import imaplib
    M = imaplib.IMAP4_SSL(server)
    try:
        M.login(user, passwd)
        M.logout()
    except:
        passwd = None
    return passwd

#XXX: should log correct answer, then quit with sys.exit
#     loop above should use imap, and quit when does not return None


if __name__ == '__main__':
    password = 'foobar'
    setpass(password)
    assert _passwd == password
    assert compare(password) == password
    assert compare('sdkmamasdkmvcassdfasdfasafgadfgadvagastqregvavagqgeav') is None


# EOF
