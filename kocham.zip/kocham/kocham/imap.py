#server = 'poczta.o2.pl'
#user = 'username'
#
_passwd = ''
_delay = 0
_server = ''
_user = ''
_fail = 10
_retry = 0.1

VERBOSE = False

def __connected():
    # see: http://stackoverflow.com/a/29854274/4646678
    import httplib
    conn = httplib.HTTPConnection('www.google.com')
    try:
        conn.request("HEAD",'/')
        return True
    except: pass
    return False

def connected(host='8.8.8.8', port=53, timeout=3):
    # see: http://stackoverflow.com/a/33117579/4646678
    import socket
    try:
        socket.setdefaulttimeout(timeout)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
        return True
    except Exception:
        pass
    return False

def internet(fail=None, retry=None, **kwds):
    fail = _fail if fail is None else fail
    retry = _retry if retry is None else retry
    import time
    start = time.time()
    while not connected(**kwds) and time.time() - start < fail:
        if VERBOSE: print 'internet connection failed, retrying...'
        time.sleep(retry)
    return connected(**kwds)

def setconnection(server=None, user=None, fail=None, retry=None):#archive=None):
    global _server, _user, _fail, _retry
    _server = _server if server is None else server
    _user = _user if user is None else user
    _fail = _fail if fail is None else fail
    _retry = _retry if retry is None else retry
   #import cache
   #cache.active(archive)
    return

def getconnection():
    return _server,_user

def setpass(password=None):#archive=None):
    global _passwd
    import getpass
    _passwd = getpass.getpass() if password is None else password
   #import cache
   #cache.active(archive)
    return

def setdelay(delay=None):
    global _delay
    _delay = 0 if delay is None else delay
    return

def dummy(server=None, user=None):
    def compare(passwd=None):
        if passwd is None:
            import getpass
            passwd = getpass.getpass()
        import time
        time.sleep(_delay)
        return passwd if passwd == _passwd else None
    return compare

compare = dummy()

def connection(server, user, **kwds):
    def login(passwd=None):
        if passwd is None:
            import getpass
            passwd = getpass.getpass()
        import imaplib
        internet(**kwds)
        M = imaplib.IMAP4_SSL(server) #NOTE: no internet will throw an error
        try:
            M.login(user, passwd)
            M.logout()
        except:
            passwd = None
        return passwd
    return login

def login(passwd=None):
    server, user = _server, _user
    if VERBOSE: print "%s %s %s\n" % (server, user, passwd) #XXX: VERBOSE
    if not server or not user:
        return compare(passwd)
    if passwd is None:
        import getpass
        passwd = getpass.getpass()
    import imaplib
    internet()
    M = imaplib.IMAP4_SSL(server) #NOTE: no internet will throw an error
    try:
        M.login(user, passwd)
        M.logout()
    except:
        passwd = None
    return passwd

#XXX: should log correct answer, then quit with sys.exit
#     loop above should use imap, and quit when does not return None


if __name__ == '__main__':
    password = 'foobar'
    setpass(password)
    assert _passwd == password
    assert compare(password) == password
    assert compare('sdkmamasdkmvsdfasdfasafgadfgadvagastqregvavagqgeav') is None


# EOF
