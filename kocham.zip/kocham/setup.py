from __future__ import with_statement, absolute_import
import os

# version
target_version = 0.1

# check if easy_install is available
try:
#   import __force_distutils__ #XXX: uncomment to force use of distutills
    from setuptools import setup
    has_setuptools = True
except ImportError:
    from distutils.core import setup
    has_setuptools = False

# build the 'setup' call
setup_code = """
setup(name='kocham',
      version='%s',
      license = 'BSD',
      platforms = ['any'],
      packages = ['kocham'],
      package_dir = {'kocham':'kocham'},
""" % target_version

# add dependencies
nltk_version = '>=3.0.4'
multiprocess_version = '>=0.70.4'
trans_version = '>=2.0.2'
stopwords_version = '>=0.2.1'
import sys
if has_setuptools:
    setup_code += """
      zip_safe=False,
      install_requires = ['nltk%s','many-stop-words%s','trans%s'],
""" % (nltk_version, stopwords_version, trans_version)
#      install_requires = ['multiprocess%s','nltk%s','many-stop-words%s'],
#""" % (multiprocess_version, nltk_version, stopwords_version)

# add the scripts, and close 'setup' call
setup_code += """
      )
"""

# exec the 'setup' code
exec(setup_code)


# install nltk corpus
import nltk
nltk.download('pl196x')
nltk.download('words')
nltk.download('brown')
nltk.download('gutenberg')
nltk.download('stopwords')


if __name__ == '__main__':
    pass


# EOF
