from kocham.solve import *
import kocham.imap as imap
import kocham.corpus as corpus
import kocham.characters as characters
corpus.VERBOSE = True
imap.VERBOSE = True
imap.setconnection('mail.server.org','username')
chars = characters.nolowercase
words = corpus.polish()
stop = corpus.more_stopwords('pl')
args = (words, chars, 10, 10)
kwds = dict(size=3, remove=stop, fixed=['kocham'])


if __name__ == '__main__':
    """ # for tp.uimap tp.uimap
    uiui(100, *args, **kwds)
    """

    """ # for tp.uimap imap
    uii(100, *args, **kwds)
    """

    """ # imap imap
    ii(*args, **kwds)
    """

    """ # map imap
    mi(*args, **kwds)
    """

    """ # for tp.uimap
    fui(100, *args, **kwds)
    """

    """ # for imap
    fi(*args, **kwds)
    """

    """ # for map
    fm(*args, **kwds)
    """

    """ # nested for
    ff(*args, **kwds)
    """

    """ # flat tp.uimap
    """
    flui(100, *args, **kwds)

    """ # flat imap
    fli(*args, **kwds)
    """

    """ # flat map
    flm(*args, **kwds)
    """

    """ # flat for
    flf(*args, **kwds)
    """


# EOF
