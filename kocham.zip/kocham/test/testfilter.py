from kocham.corpus import *
from kocham.imap import *
setpass('catdog')#@123')
#words = ['cat','dog','god','lamb','hose','apple','foo','bar','blue','red']
words = ['cat','dog','foo','bar']
#pwds = ifilter(words, maxpass=10, minlen=3, maxlen=3, most_common=5000, size=2, fixed=('cat','dog'), remove=stopwords('english'))
#pwds = ifilter(words, maxpass=10, minlen=3, maxlen=3, most_common=5000, size=2, fixed=('cat',), remove=stopwords('english'))
pwds = ifilter(words, maxpass=10, minlen=3, maxlen=3, most_common=5000, size=2, fixed=(), remove=stopwords('english'))
#pwds = ifilter(words, maxpass=10, minlen=3, maxlen=3, most_common=5000, size=3, fixed=(), remove=stopwords('english'))


if __name__ == '__main__':
     print tuple(pwds)
#    compare = lambda x:x
#    for i in pwds:
#       x = compare(''.join(i))
#       if x: print x


# EOF
