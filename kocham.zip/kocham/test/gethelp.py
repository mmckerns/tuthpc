from kocham.solve import *
print uiui.__doc__
