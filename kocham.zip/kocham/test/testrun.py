from kocham.solve import *
import kocham.imap as imap
import kocham.corpus as corpus
corpus.VERBOSE = True
imap.setpass('catdog@123')
chars = ''
words = []
fixed = ['catdog@123']
args = (words, chars, 10, 10)
kwds = dict(minword=3, maxword=3, size=1, fixed=fixed)


if __name__ == '__main__':
    """ # for tp.uimap tp.uimap
    """
    uiui(100, *args, **kwds)

    """ # for tp.uimap imap
    """
    uii(100, *args, **kwds)

    """ # imap imap
    """
    ii(*args, **kwds)

    """ # map imap
    """
    mi(*args, **kwds)

    """ # for tp.uimap
    """
    fui(100, *args, **kwds)

    """ # for imap
    """
    fi(*args, **kwds)

    """ # for map
    """
    fm(*args, **kwds)

    """ # nested for
    """
    ff(*args, **kwds)

    """ # flat tp.uimap
    """
    flui(100, *args, **kwds)

    """ # flat imap
    """
    fli(*args, **kwds)

    """ # flat map
    """
    flm(*args, **kwds)

    """ # flat for
    """
    flf(*args, **kwds)


# EOF
