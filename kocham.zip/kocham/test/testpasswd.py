from kocham.corpus import *
from kocham.imap import *
setpass('catdog@123')
#words = bible()
#words = ['cat','dog','god','lamb','hose','apple','foo','bar','blue','red']
words = ['cat','dog','foo','bar']
#pwds = ipassword(words, '1234567890!@#$%^&*', 6, 10, minword=3, maxword=8, most_common=5000, size=2)
#pwds = ipassword(words, '1234567890!@#$%^&*', 10, 10, minword=3, maxword=3, most_common=5000, size=2, fixed=('cat',), remove=stopwords('english'))
pwds = ipassword(words, '1234!@', 10, 10, minword=3, maxword=3, most_common=5000, size=2, fixed=('cat',), remove=stopwords('english'))


if __name__ == '__main__':
    for p in pwds:
        p = tuple(p)
        print repeats(p)
        print len(p), len(set(p))
#       for i in p:
#           x = compare(i)
#           if x: print x
#       
        break


# EOF
