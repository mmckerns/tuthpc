from kocham.characters import *
from kocham.corpus import repeats
from kocham.imap import *
#chars = '1234567890!@#$%^&*'
chars = '1234!@'
#pwds = icombinations(chars, maxlen=4, minlen=4)
pwds = icombinations(chars, maxlen=2, minlen=2)


if __name__ == '__main__':
     pwds = tuple(pwds)
     print pwds
#    print repeats(pwds)
#    print len(pwds), len(set(pwds))


# EOF
